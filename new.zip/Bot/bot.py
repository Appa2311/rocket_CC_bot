from main import run_bot
run_bot()