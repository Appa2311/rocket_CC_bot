import base64
exec(base64.b64decode("").decode())